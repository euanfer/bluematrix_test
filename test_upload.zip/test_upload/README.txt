I've completed the test using Python. The code should run in any Python enivronment, I used Spyder.
I've included the figures I used to visualise the data incase you have any issues displaying them.

The script loads the data in, then cuts it down to [datetimes, GUIDs, action, server].
It is then sorted by GUID the datetime so that each exchange is grouped together.
A few checks are then run on the sorted data.

A function extracts the request and response time from each exchange.
Some analysis of these times show that 20000/200000 = 10% of requests are slow
and 12000/200000 = 6% of the responses are slow.
1172 ~ 1200/200000 = 0.6% of exchanges are doubly slow as expected.

The slow requests are due to bad frontends and slow responses are due to bad workers.
Bad frontends have no effect on repsonse time and vice versa.

The proportion of bad servers aligns exactly with the proportion of slow requests/responses.