# -*- coding: utf-8 -*-
"""
Created on Tue Jul 11 11:32:53 2023
BlueMatrix test
Euan Ferguson
"""

import numpy as np
from matplotlib import pyplot as plt
from datetime import datetime
from datetime import timedelta

# loading in the logs

sample = np.loadtxt('sample.log', delimiter = ' ', dtype = str)

print('Shape:   ', sample.shape)                  # checking size of data

# organisng the data

a = np.delete(sample, [3,4,5,6], axis = 1)          # dropping unncessary columns

ind = np.lexsort((a[:,0], a[:,1]))                  # sorting data by GUID then time to group exchanges together
sample_sorted = a[ind]   

print('No. unique GUIDs/exhanges:   ', len(np.unique(sample[:,1])))
print('Actions and their counts:   ', np.unique(sample[:,2], return_counts = True))

comb = np.sum((sample_sorted[:,2] != np.tile(['0', 'HANDLE', 'RESPOND'], int(sample.shape[0]/3))))     # double checking the time sort has worked ie all exchanges grouped together as GET/POST - HANLDE - REPSOND

if comb == int(sample.shape[0]/3):
    print('Sort test passed')
    
else:
    print('Sort test failed')



def get_exchanges(log):
    """
    Function to get exhange times from a log
    input: [[datetime, GUID, action, server],...]     should be sorted by GUID then datetime
    output: [[frontend], [worker], [request_time], [repsonse_time]]     entry for each exchange in the log
    """
    frontend_list = []
    worker_list = []
    
    t1_list = []
    t2_list = []
    
    for i in range(int(sample.shape[0]/3)):
                   
        frontend = log[i*3, 3]
        worker = log[i*3+1, 3]
                   
        frontend_list.append(frontend)
        worker_list.append(worker)
                   
        t1 = datetime.fromisoformat(log[i*3 + 1, 0]) - datetime.fromisoformat(log[i*3, 0])
        t2 = datetime.fromisoformat(log[i*3 + 2, 0]) - datetime.fromisoformat(log[i*3+1, 0])
                   
        t1_list.append(t1)
        t2_list.append(t2)
                   
    output = np.array([frontend_list, worker_list, np.array(t1_list)/timedelta(microseconds = 1), np.array(t2_list)/timedelta(microseconds = 1)])
                   
    return output

exchange_data = get_exchanges(np.array(sample_sorted))

print(exchange_data[:,0])       # check format is as expected

# histogram of request times

plt.hist(exchange_data[2])
plt.title('Histogram of Request Times')
plt.xlabel('Time (microseconds)')
plt.ylabel('Counts')
plt.show()

print('Number of slow requests:   ', np.sum(exchange_data[2] > 4e5))     # I played aound with the number for the cutoff and this is appropriate

# histogram of response times

plt.hist(exchange_data[3])
plt.title('Histogram of Response Times')
plt.xlabel('Time (microseconds)')
plt.ylabel('Counts')
plt.show()

print('Number of slow responses:   ', np.sum(exchange_data[3] > 4e5))

# histogram of exhange times

plt.hist(exchange_data[2] + exchange_data[3])
plt.title('Histogram of Exchange Times')
plt.xlabel('Time (microseconds)')
plt.ylabel('Counts')
plt.show()

print('Number of exchanges with slow requests and responses:   ', np.sum(exchange_data[2] + exchange_data[3] > 1.2e6))   # expect around 1200 here

# making sure request delays are only dependent on bad frontend and response delays only dependent on bad workers
# (this is already implied from the numbers printed previously)

exchange_data[0][exchange_data[2]>4e5]     # getting frontends involved in slow requests

# plotting histrograms for one of them

plt.hist(exchange_data[2][exchange_data[0] == 'frontend3'])
plt.title('Request Times involving frontend3')
plt.xlabel('Time (microseconds)')
plt.ylabel('Counts')
plt.show()

plt.hist(exchange_data[3][exchange_data[0] == 'frontend3'])
plt.title('Response Times involving frontend3')
plt.xlabel('Time (microseconds)')
plt.ylabel('Counts')

# These show that all requests involving frontend3 are slow and that a bad frontend does not affect response time

# Getting the culprits

slow_frontends = np.unique(exchange_data[0][exchange_data[2] > 4e5])
slow_workers = np.unique(exchange_data[1][exchange_data[3] > 4e5])

w_workers = np.unique(exchange_data[1][exchange_data[3] > 4e5])
print('Slow Frontends:   ', slow_frontends)
print('Slow workers:   ', slow_workers)

np.savetxt('slow_frontends.txt', slow_frontends, fmt  = '%s')
np.savetxt('slow_workers.txt', slow_workers, fmt  = '%s')

# Sanity check: 2/20 = 20000/200000, 3/50 = 12000/200000  as required
